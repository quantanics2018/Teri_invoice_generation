// Distributer_Details.js
import React from 'react';

const suma = (props) => {
  return (
    <div>
      <p>Age: {props.agee}</p>
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aliquam molestiae saepe, numquam deleniti exercitationem nemo, voluptatem nobis iusto perspiciatis, consequatur asperiores inventore dolor esse cupiditate quo expedita nesciunt blanditiis totam.
      {/* You can use the agee prop as needed in the component */}
    </div>
  );
}

export default suma;
