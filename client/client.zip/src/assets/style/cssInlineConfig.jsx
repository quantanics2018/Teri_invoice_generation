const UserActionBtn = { backgroundColor: 'red', color: 'white', borderRadius: '7px', minWidth: '120px', whiteSpace:'nowrap' }
const width = '100px';
const SaveBtn = { color: 'green', borderColor: 'green', width };
const CancelBtn = { color: 'Orange', borderColor: 'Orange', width };


export { UserActionBtn, SaveBtn ,CancelBtn};